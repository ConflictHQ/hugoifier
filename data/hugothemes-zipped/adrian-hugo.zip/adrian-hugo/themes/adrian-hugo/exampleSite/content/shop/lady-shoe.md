---
title: "Lady Shoe"
date: 2019-11-25T13:39:07+06:00
draft: false

# meta description
description : "Nice and classy lady shoe"

# page title background image
bgImage : "images/backgrounds/header-bg.jpg"

# product Images
# first image will be shown in the product page
images:
  - "images/products/shoe-1.jpg"
  - "images/products/shoe-4.jpg"

# product Price
price: "49.00"
priceBefore: "50.00"

# categories
categories : ["shoe"]

# colors 
colors : ["black","blue"]

# sizes
sizes : ["S","M","XL"]

# weight
productWeight : "800 G"

# dimentions
dimensions : "10 x 10 x 15 cm"

# materials
materials : "100% Leather"
---

Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.

#### Product Features

* Mapped with 3M™ Thinsulate™ Insulation [40G Body / Sleeves / Hood]
* Embossed Taffeta Lining
* DRYRIDE Durashell™ 2-Layer Oxford Fabric [10,000MM, 5,000G]