---
# banner
banner:
  title : "Hi! I’m <br> Christoher <br> UX designer"

# about
about:
  enable : true
  content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
  button:
    enable : true
    label : "know more"
    URL : "about"

# skill
skill:
  enable : true
  title : "Skills"
  item:
    - title : "Web Design"
      progress : "90%"
      color : "#fdb157"
      
    - title : "Logo Design"
      progress : "60%"
      color : "#9473e6"
      
    - title : "After Effects"
      progress : "80%"
      color : "#bdecf6"
      
    - title : "Web App"
      progress : "70%"
      color : "#ffbcaa"

# experience
experience:
  enable : true
  title : "Experience"
  item: 
    - logo : "images/experience/icon-1.png"
      title : "Junior UX Designer"
      company : "WEBEX"
      duration : "Jan 2007 - Feb 2009"
      
    - logo : "images/experience/icon-2.png"
      title : "UX & UI Designer"
      company : "AUGMEDIX"
      duration : "Mar 2009 - Aug 2014"
      
    - logo : "images/experience/icon-1.png"
      title : "Senior UI Designer"
      company : "THEMEFISHER"
      duration : "Sep 2014 - Present"

# education
education:
  enable : true
  title : "Education"
  item:
    - title : "Marters in UX Design"
      year : "2006"
      academy : "Masassusets Institute of Technology"
      
    - title : "Honours in Fine Arts"
      year : "2004"
      academy : "Harvard University"
      
    - title : "Higher Secondary Certificat"
      year : "2000"
      academy : "Cardiff School"
      
    - title : "Secondary School Certificate"
      year : "1998"
      academy : "Cardiff School"

# service
service:
  enable : true
  title : "Services"
  item:
    - title : "UI Design"
      icon : "ti-palette"
      content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
      highlighted : false

    - title : "UX Design"
      icon : "ti-vector"
      content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
      highlighted : true

    - title : "Interaction Design"
      icon : "ti-panel"
      content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
      highlighted : false

# portfolio
portfolio:
  enable : true
  title : "Portfolio"
  item_show : 5
  # portfolio item comes from 'data/portfolio.yml' item.

# testimonial
testimonial:
  enable : true
  title : "Testimonials"
  item:
    - name : "Jesica Gomez"
      image : "images/testimonial/client-1.png"
      designation : "CEO, Funder"
      content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, <strong>quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</strong> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
      
    - name : "Shirley Scot"
      image : "images/testimonial/client-2.png"
      designation : "CEO, Funder"
      content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, <strong>quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</strong> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
      
    - name : "Jessica Julie"
      image : "images/testimonial/client-3.png"
      designation : "CEO, Funder"
      content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, <strong>quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</strong> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."

# client logo slider
clients_logo_slider:
  enable : true
  item:
    - logo : "images/clients-logo/client-logo-1.png"
      URL : "http://examplesite.com"
      
    - logo : "images/clients-logo/client-logo-2.png"
      URL : "#"
      
    - logo : "images/clients-logo/client-logo-3.png"
      URL : "http://examplesite.com"
      
    - logo : "images/clients-logo/client-logo-4.png"
      URL : "#"
      
    - logo : "images/clients-logo/client-logo-5.png"
      URL : "http://examplesite.com"
      
    - logo : "images/clients-logo/client-logo-1.png"
      URL : "#"
      
    - logo : "images/clients-logo/client-logo-2.png"
      URL : "http://examplesite.com"
      
    - logo : "images/clients-logo/client-logo-3.png"
      URL : "#"
      
    - logo : "images/clients-logo/client-logo-4.png"
      URL : "http://examplesite.com"
      
    - logo : "images/clients-logo/client-logo-5.png"
      URL : "#"

# blog
blog:
  enable : true
  title : "Blogs"
  # blog post comes from "content/blog" folder
---
